# 🍽️ NPS Restaurante — Guia de Instalação

## O que esse sistema faz

- ✅ Dashboard NPS com Perdizes, Tatuapé e Moema
- ✅ Escala 8-10 promotor, 7 neutro, 0-6 detrator
- ✅ Upload de planilha CSV e disparo via WhatsApp (Zenvia)
- ✅ Página pública para cliente responder a pesquisa
- ✅ Carrinho abandonado via planilha OU webhook automático do WooCommerce
- ✅ Alertas de reclamação em tempo real no painel
- ✅ Relatório semanal automático (todo domingo às 20h)

---

## PARTE 1 — Instalar na sua hospedagem

### Requisitos
- Node.js 18+ instalado no servidor
- Acesso SSH à hospedagem (Hostinger, DigitalOcean, etc.)

### Passo a passo

```bash
# 1. Envie os arquivos para o servidor (via FTP ou Git)
# A pasta nps-system deve ficar em /var/www/nps ou similar

# 2. Entre na pasta backend
cd /var/www/nps/backend

# 3. Instale as dependências
npm install

# 4. Copie o arquivo de configuração
cp .env.example .env

# 5. Edite o .env com suas credenciais (veja Parte 2)
nano .env

# 6. Inicie o servidor
node server.js
# Ou com PM2 para manter rodando sempre:
npm install -g pm2
pm2 start server.js --name nps-restaurante
pm2 save
pm2 startup
```

O sistema estará disponível em: `http://seuservidor:3001`

Para acessar via domínio (ex: nps.seurestaurante.com.br), configure um proxy reverso com Nginx:

```nginx
server {
    server_name nps.seurestaurante.com.br;
    location / {
        proxy_pass http://localhost:3001;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

---

## PARTE 2 — Configurar a Zenvia (WhatsApp)

1. Acesse **zenvia.com** e crie uma conta
2. Vá em **Canais > WhatsApp**
3. Cadastre o número do restaurante
4. Aguarde a verificação (até 24h)
5. Copie o **Token da API** e o **número From**
6. Cole no arquivo `.env`:

```
ZENVIA_TOKEN=seu_token_aqui
ZENVIA_FROM=5511SEUNUMERO
```

---

## PARTE 3 — Integrar com WooCommerce (carrinho em tempo real)

Isso faz o sistema receber o carrinho abandonado AUTOMATICAMENTE, sem precisar de planilha.

### No WooCommerce:

1. Instale o plugin **WooCommerce Abandoned Cart Lite** (gratuito)
   - WordPress > Plugins > Adicionar novo > buscar "Abandoned Cart Lite"

2. Configure o plugin:
   - Tempo para considerar abandono: **30 minutos**
   - Vá em **Settings > Webhook**
   - URL do Webhook: `https://seudominio.com/webhook/woocommerce`
   - Secret: coloque o mesmo valor que está em `WEBHOOK_SECRET` no seu `.env`

3. Pronto! A partir de agora, quando alguém abandonar o carrinho:
   - O plugin avisa seu sistema automaticamente
   - Seu sistema espera 30 min
   - Se a pessoa não finalizou, dispara o WhatsApp

---

## PARTE 4 — Fluxo diário de trabalho

### Pesquisa NPS
1. Você recebe a planilha por email com os clientes do dia
2. Acessa o dashboard em `https://seudominio.com`
3. Vai na aba **⭐ Disparar NPS**
4. Arrasta o CSV
5. Clica **Disparar para todos**
6. Os clientes recebem o link no WhatsApp
7. Quando respondem, aparece no dashboard automaticamente
8. Reclamações (nota 0-6) aparecem com alerta vermelho na aba 🚨

### Carrinho abandonado
- **Com WooCommerce**: automático, não precisa fazer nada
- **Com planilha manual**: mesmo processo do NPS, na aba 🛒

---

## Estrutura de arquivos

```
nps-system/
├── backend/
│   ├── server.js        ← Servidor principal
│   ├── db.js            ← Banco de dados (JSON)
│   ├── whatsapp.js      ← Integração Zenvia
│   ├── .env             ← Suas credenciais (não compartilhe!)
│   └── package.json
├── frontend/
│   ├── index.html       ← Dashboard (painel interno)
│   └── pesquisa.html    ← Página que o cliente responde
└── data/                ← Criado automaticamente
    ├── nps_responses.json
    ├── dispatch_queue.json
    ├── cart_queue.json
    └── send_log.json
```

---

## Mensagens enviadas

### NPS
> Olá, [Nome]! 😊
> Obrigado por visitar nosso restaurante na unidade *[Unidade]*!
> Sua opinião é muito importante para continuarmos melhorando.
> De *0 a 10*, quanto você recomendaria nosso restaurante para um amigo?
> 👉 [link da pesquisa]

### Carrinho abandonado
> Olá, [Nome]! 👋
> Notamos que você montou um pedido incrível na nossa unidade *[Unidade]* mas não finalizou.
> 🍽️ *[Item]* está esperando por você!
> Finalize agora e garanta seu pedido:
> 👉 [link do checkout]

---

## Dúvidas frequentes

**O número precisa estar no celular?**
Não. Após migrar para a API Zenvia, o número só funciona via API. Se precisar usar no celular também, cadastre um número separado.

**Quantas mensagens posso enviar?**
Depende do plano Zenvia. O básico suporta centenas por dia tranquilamente.

**O banco de dados pode crescer demais?**
Os arquivos JSON são simples e leves. Para volumes muito grandes (10.000+ respostas), migramos para PostgreSQL — o código já está preparado para isso.

**Como faço backup dos dados?**
Copie a pasta `/data` periodicamente. São arquivos de texto simples.
