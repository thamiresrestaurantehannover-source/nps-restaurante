// server.js — Servidor principal
require('dotenv').config();

const express  = require('express');
const cors     = require('cors');
const multer   = require('multer');
const { parse } = require('csv-parse/sync');
const path     = require('path');
const fs       = require('fs');
const cron     = require('node-cron');

const db         = require('./db');
const { sendWhatsApp, npsMessage, cartMessage } = require('./whatsapp');

const app    = express();
const upload = multer({ storage: multer.memoryStorage() });

app.use(cors());
app.use(express.json());

// Serve o frontend estático
app.use(express.static(path.join(__dirname, '..', 'frontend')));

const BASE_URL = process.env.BASE_URL || `http://localhost:${process.env.PORT || 3001}`;

// ══════════════════════════════════════════════════════════════════════════
// ROTAS NPS
// ══════════════════════════════════════════════════════════════════════════

// Upload CSV de clientes NPS e enfileira disparos
app.post('/api/nps/upload', upload.single('file'), (req, res) => {
  try {
    const text    = req.file.buffer.toString('utf8');
    const records = parse(text, { columns: true, skip_empty_lines: true, trim: true });

    const contacts = records.map(r => ({
      name:  r.nome  || r.name  || '',
      phone: r.telefone || r.phone || '',
      unit:  r.unidade  || r.unit  || '',
    })).filter(c => c.phone);

    const queued = db.dispatchQueue.add(contacts);
    res.json({ success: true, count: queued.length });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Lista fila NPS
app.get('/api/nps/queue', (req, res) => {
  res.json(db.dispatchQueue.all().slice(-200).reverse());
});

// Dispara TODOS os pendentes da fila NPS
app.post('/api/nps/dispatch-all', async (req, res) => {
  const pending = db.dispatchQueue.pending();
  if (!pending.length) return res.json({ sent: 0 });

  let sent = 0;
  for (const contact of pending) {
    try {
      const surveyUrl = `${BASE_URL}/pesquisa?id=${contact.id}`;
      const msg       = npsMessage(contact.name, contact.unit, surveyUrl);
      await sendWhatsApp(contact.phone, msg);
      db.dispatchQueue.updateStatus(contact.id, 'sent');
      db.sendLog.add({ type: 'nps', to: contact.phone, name: contact.name, unit: contact.unit });
      sent++;
      // Pequena pausa para não sobrecarregar a API
      await new Promise(r => setTimeout(r, 300));
    } catch (err) {
      db.dispatchQueue.updateStatus(contact.id, 'error', err.message);
    }
  }
  res.json({ sent, total: pending.length });
});

// Dispara UM contato NPS
app.post('/api/nps/dispatch/:id', async (req, res) => {
  const queue = db.dispatchQueue.all();
  const item  = queue.find(c => c.id === req.params.id);
  if (!item) return res.status(404).json({ error: 'Não encontrado' });

  try {
    const surveyUrl = `${BASE_URL}/pesquisa?id=${item.id}`;
    const msg       = npsMessage(item.name, item.unit, surveyUrl);
    await sendWhatsApp(item.phone, msg);
    db.dispatchQueue.updateStatus(item.id, 'sent');
    db.sendLog.add({ type: 'nps', to: item.phone, name: item.name, unit: item.unit });
    res.json({ success: true });
  } catch (err) {
    db.dispatchQueue.updateStatus(item.id, 'error', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ── Página pública de pesquisa NPS (respondida pelo cliente) ──────────────
app.get('/pesquisa', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'frontend', 'pesquisa.html'));
});

// Cliente submete resposta NPS
app.post('/api/nps/responder', (req, res) => {
  const { queueId, score, comment } = req.body;
  if (!score || score < 0 || score > 10) return res.status(400).json({ error: 'Nota inválida' });

  // Busca dados do cliente na fila
  const queue  = db.dispatchQueue.all();
  const item   = queue.find(c => c.id === queueId) || {};

  const entry = db.nps.add({
    queueId,
    name:    item.name  || 'Cliente',
    phone:   item.phone || '',
    unit:    item.unit  || '',
    score:   parseInt(score),
    comment: comment || '',
  });

  res.json({ success: true, id: entry.id });
});

// ══════════════════════════════════════════════════════════════════════════
// ROTAS DASHBOARD NPS
// ══════════════════════════════════════════════════════════════════════════

app.get('/api/dashboard', (req, res) => {
  const { unit } = req.query;
  const all      = db.nps.byUnit(unit);
  const byUnit   = ['Perdizes','Tatuapé','Moema'].map(u => ({
    unit: u,
    ...db.nps.calcNPS(db.nps.byUnit(u)),
  }));

  res.json({
    nps:        db.nps.calcNPS(all),
    byUnit,
    responses:  all.slice(-100).reverse(),
    complaints: db.nps.unreadComplaints(),
  });
});

app.post('/api/nps/read/:id', (req, res) => {
  db.nps.markRead(req.params.id);
  res.json({ success: true });
});

// ══════════════════════════════════════════════════════════════════════════
// ROTAS CARRINHO ABANDONADO
// ══════════════════════════════════════════════════════════════════════════

// Upload CSV de carrinhos
app.post('/api/cart/upload', upload.single('file'), (req, res) => {
  try {
    const text    = req.file.buffer.toString('utf8');
    const records = parse(text, { columns: true, skip_empty_lines: true, trim: true });

    const contacts = records.map(r => ({
      name:  r.nome  || r.name  || '',
      phone: r.telefone || r.phone || '',
      unit:  r.unidade  || r.unit  || '',
      cart:  r.item  || r.cart  || '',
      value: r.valor || r.value || '',
    })).filter(c => c.phone);

    const queued = db.cartQueue.add(contacts);
    res.json({ success: true, count: queued.length });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Lista fila carrinho
app.get('/api/cart/queue', (req, res) => {
  res.json(db.cartQueue.all().slice(-200).reverse());
});

// Dispara TODOS os carrinhos pendentes
app.post('/api/cart/dispatch-all', async (req, res) => {
  const pending = db.cartQueue.pending();
  if (!pending.length) return res.json({ sent: 0 });

  let sent = 0;
  for (const contact of pending) {
    try {
      const checkoutUrl = process.env.CHECKOUT_URL || 'https://seusite.com.br/checkout';
      const msg = cartMessage(contact.name, contact.cart || 'seu pedido', contact.unit, checkoutUrl);
      await sendWhatsApp(contact.phone, msg);
      db.cartQueue.updateStatus(contact.id, 'sent');
      db.sendLog.add({ type: 'cart', to: contact.phone, name: contact.name, unit: contact.unit });
      sent++;
      await new Promise(r => setTimeout(r, 300));
    } catch (err) {
      db.cartQueue.updateStatus(contact.id, 'error', err.message);
    }
  }
  res.json({ sent, total: pending.length });
});

// Dispara UM carrinho
app.post('/api/cart/dispatch/:id', async (req, res) => {
  const item = db.cartQueue.all().find(c => c.id === req.params.id);
  if (!item) return res.status(404).json({ error: 'Não encontrado' });

  try {
    const checkoutUrl = process.env.CHECKOUT_URL || 'https://seusite.com.br/checkout';
    const msg = cartMessage(item.name, item.cart || 'seu pedido', item.unit, checkoutUrl);
    await sendWhatsApp(item.phone, msg);
    db.cartQueue.updateStatus(item.id, 'sent');
    db.sendLog.add({ type: 'cart', to: item.phone, name: item.name, unit: item.unit });
    res.json({ success: true });
  } catch (err) {
    db.cartQueue.updateStatus(item.id, 'error', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ══════════════════════════════════════════════════════════════════════════
// WEBHOOK WOOCOMMERCE — carrinho abandonado em tempo real
// ══════════════════════════════════════════════════════════════════════════

app.post('/webhook/woocommerce', async (req, res) => {
  // Valida o secret para segurança
  const secret = req.headers['x-wc-webhook-secret'] || req.query.secret;
  if (process.env.WEBHOOK_SECRET && secret !== process.env.WEBHOOK_SECRET) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const order = req.body;
  res.json({ received: true }); // Responde rápido para o WooCommerce não retentar

  try {
    // Extrai dados do pedido abandonado
    const name  = `${order.billing?.first_name || ''} ${order.billing?.last_name || ''}`.trim();
    const phone = order.billing?.phone || '';
    const items = (order.line_items || []).map(i => i.name).join(', ') || 'seu pedido';
    const total = order.total ? `R$ ${order.total}` : '';
    const unit  = order.meta_data?.find(m => m.key === 'unidade')?.value || 'nossa unidade';
    const orderId = order.id?.toString();

    if (!phone || !orderId) return;
    if (db.cartQueue.alreadyQueued(orderId)) return; // evita duplicar

    // Enfileira com delay de 30 minutos antes de disparar
    const [queued] = db.cartQueue.add([{ name, phone, unit, cart: items, value: total, orderId }]);

    // Aguarda 30 minutos — se o cliente finalizar antes, o status já terá mudado
    setTimeout(async () => {
      const current = db.cartQueue.all().find(c => c.id === queued.id);
      if (!current || current.status !== 'pending') return;

      const checkoutUrl = `${process.env.CHECKOUT_URL}?order_id=${orderId}`;
      const msg = cartMessage(name, items, unit, checkoutUrl);
      try {
        await sendWhatsApp(phone, msg);
        db.cartQueue.updateStatus(queued.id, 'sent');
        db.sendLog.add({ type: 'cart_webhook', to: phone, name, unit, orderId });
      } catch (err) {
        db.cartQueue.updateStatus(queued.id, 'error', err.message);
      }
    }, 30 * 60 * 1000); // 30 minutos

  } catch (err) {
    console.error('Webhook error:', err.message);
  }
});

// ══════════════════════════════════════════════════════════════════════════
// RELATÓRIO SEMANAL — todo domingo às 20h
// ══════════════════════════════════════════════════════════════════════════

cron.schedule('0 20 * * 0', () => {
  const all  = db.nps.all();
  const nps  = db.nps.calcNPS(all);
  const date = new Date().toLocaleDateString('pt-BR');
  console.log(`\n📊 RELATÓRIO SEMANAL — ${date}`);
  console.log(`NPS Score: ${nps.score} | Promotores: ${nps.promoters} | Neutros: ${nps.neutrals} | Detratores: ${nps.detractors}`);
  ['Perdizes','Tatuapé','Moema'].forEach(u => {
    const un = db.nps.calcNPS(db.nps.byUnit(u));
    console.log(`  ${u}: NPS ${un.score} (${un.total} respostas)`);
  });
});

// ══════════════════════════════════════════════════════════════════════════
// START
// ══════════════════════════════════════════════════════════════════════════

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`\n🍽️  NPS Restaurante rodando em http://localhost:${PORT}`);
  console.log(`📊 Dashboard:  http://localhost:${PORT}`);
  console.log(`📝 Pesquisa:   http://localhost:${PORT}/pesquisa`);
  console.log(`🔗 Webhook WC: http://localhost:${PORT}/webhook/woocommerce\n`);
});
