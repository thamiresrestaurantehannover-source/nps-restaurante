// whatsapp.js — Disparo de mensagens via Zenvia
require('dotenv').config();
const https = require('https');

const TOKEN = process.env.ZENVIA_TOKEN;
const FROM  = process.env.ZENVIA_FROM;

// ── Mensagens prontas ──────────────────────────────────────────────────────

function npsMessage(name, unit, surveyUrl) {
  return `Olá, ${name}! 😊\n\nObrigado por visitar nosso restaurante na unidade *${unit}*!\n\nSua opinião é muito importante para continuarmos melhorando.\n\nDe *0 a 10*, quanto você recomendaria nosso restaurante para um amigo ou familiar?\n\n👉 Responda aqui: ${surveyUrl}\n\nLeva menos de 1 minutinho! 🙏`;
}

function cartMessage(name, item, unit, checkoutUrl) {
  return `Olá, ${name}! 👋\n\nNotamos que você montou um pedido incrível na nossa unidade *${unit}* mas não finalizou.\n\n🍽️ *${item}* está esperando por você!\n\nFinalize agora e garanta seu pedido:\n👉 ${checkoutUrl}\n\nQualquer dúvida estamos aqui! 😄`;
}

// ── Envio via Zenvia ───────────────────────────────────────────────────────

function sendWhatsApp(to, message) {
  return new Promise((resolve, reject) => {
    // Limpa o número: remove tudo que não é dígito e garante 55 na frente
    let phone = to.replace(/\D/g, '');
    if (!phone.startsWith('55')) phone = '55' + phone;

    const body = JSON.stringify({
      from: FROM,
      to:   phone,
      contents: [{ type: 'text', text: message }],
    });

    const options = {
      hostname: 'api.zenvia.com',
      path:     '/v2/channels/whatsapp/messages',
      method:   'POST',
      headers:  {
        'Content-Type':  'application/json',
        'X-API-TOKEN':   TOKEN,
        'Content-Length': Buffer.byteLength(body),
      },
    };

    const req = https.request(options, res => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        if (res.statusCode >= 200 && res.statusCode < 300) {
          resolve({ success: true, messageId: JSON.parse(data).id });
        } else {
          reject(new Error(`Zenvia error ${res.statusCode}: ${data}`));
        }
      });
    });

    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

module.exports = { sendWhatsApp, npsMessage, cartMessage };
