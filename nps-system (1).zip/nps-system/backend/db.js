// db.js — Banco de dados simples em JSON
// Em produção pode trocar por PostgreSQL ou MySQL sem mudar o resto do código

const fs   = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', 'data');
const FILES = {
  nps_responses:    path.join(DATA_DIR, 'nps_responses.json'),
  dispatch_queue:   path.join(DATA_DIR, 'dispatch_queue.json'),
  cart_queue:       path.join(DATA_DIR, 'cart_queue.json'),
  send_log:         path.join(DATA_DIR, 'send_log.json'),
};

// Garante que os arquivos existem
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
Object.values(FILES).forEach(f => { if (!fs.existsSync(f)) fs.writeFileSync(f, '[]'); });

function read(file)        { return JSON.parse(fs.readFileSync(file, 'utf8')); }
function write(file, data) { fs.writeFileSync(file, JSON.stringify(data, null, 2)); }

// ── NPS Respostas ──────────────────────────────────────────────────────────
const nps = {
  all()        { return read(FILES.nps_responses); },
  add(entry)   {
    const list = read(FILES.nps_responses);
    const record = { id: Date.now().toString(), createdAt: new Date().toISOString(), read: false, ...entry };
    list.push(record);
    write(FILES.nps_responses, list);
    return record;
  },
  markRead(id) {
    const list = read(FILES.nps_responses);
    const idx  = list.findIndex(r => r.id === id);
    if (idx !== -1) { list[idx].read = true; write(FILES.nps_responses, list); }
  },
  byUnit(unit)   { return nps.all().filter(r => !unit || unit === 'all' || r.unit === unit); },
  complaints()   { return nps.all().filter(r => r.score <= 6); },
  unreadComplaints() { return nps.all().filter(r => r.score <= 6 && !r.read); },
  calcNPS(list)  {
    if (!list.length) return { score: 0, promoters: 0, neutrals: 0, detractors: 0, total: 0 };
    const promoters  = list.filter(r => r.score >= 8).length;
    const detractors = list.filter(r => r.score <= 6).length;
    const neutrals   = list.filter(r => r.score === 7).length;
    return {
      score:      Math.round(((promoters - detractors) / list.length) * 100),
      promoters, neutrals, detractors,
      total:      list.length,
    };
  },
};

// ── Fila de disparo NPS ────────────────────────────────────────────────────
const dispatchQueue = {
  all()         { return read(FILES.dispatch_queue); },
  pending()     { return read(FILES.dispatch_queue).filter(r => r.status === 'pending'); },
  add(contacts) {
    const list = read(FILES.dispatch_queue);
    const now  = new Date().toISOString();
    const newItems = contacts.map(c => ({ id: Date.now().toString() + Math.random(), status: 'pending', createdAt: now, ...c }));
    write(FILES.dispatch_queue, [...list, ...newItems]);
    return newItems;
  },
  updateStatus(id, status, error = null) {
    const list = read(FILES.dispatch_queue);
    const idx  = list.findIndex(r => r.id === id);
    if (idx !== -1) {
      list[idx].status    = status;
      list[idx].updatedAt = new Date().toISOString();
      if (error) list[idx].error = error;
      write(FILES.dispatch_queue, list);
    }
  },
};

// ── Fila de carrinho abandonado ────────────────────────────────────────────
const cartQueue = {
  all()         { return read(FILES.cart_queue); },
  pending()     { return read(FILES.cart_queue).filter(r => r.status === 'pending'); },
  add(contacts) {
    const list    = read(FILES.cart_queue);
    const now     = new Date().toISOString();
    const newItems = contacts.map(c => ({ id: Date.now().toString() + Math.random(), status: 'pending', createdAt: now, ...c }));
    write(FILES.cart_queue, [...list, ...newItems]);
    return newItems;
  },
  updateStatus(id, status, error = null) {
    const list = read(FILES.cart_queue);
    const idx  = list.findIndex(r => r.id === id);
    if (idx !== -1) {
      list[idx].status    = status;
      list[idx].updatedAt = new Date().toISOString();
      if (error) list[idx].error = error;
      write(FILES.cart_queue, list);
    }
  },
  // Evita mandar duplicado pro mesmo pedido
  alreadyQueued(orderId) {
    return read(FILES.cart_queue).some(r => r.orderId === orderId);
  },
};

// ── Log de envios ──────────────────────────────────────────────────────────
const sendLog = {
  add(entry) {
    const list = read(FILES.send_log);
    list.push({ id: Date.now().toString(), createdAt: new Date().toISOString(), ...entry });
    write(FILES.send_log, list);
  },
  all() { return read(FILES.send_log); },
};

module.exports = { nps, dispatchQueue, cartQueue, sendLog };
